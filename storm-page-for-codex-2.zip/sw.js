// Service worker for Daniel's Storm Page: shows storm alerts delivered by browser push.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
self.addEventListener('push', (e) => {
  let d = {};
  try { d = e.data ? e.data.json() : {}; } catch { d = { body: e.data && e.data.text() }; }
  // A push with no payload is the "Send me a test" ping from the subscriber service.
  if (!e.data) d = { title: "Daniel's Storm Page: test", body: 'Test notification. Storm alerts will reach this device.' };
  e.waitUntil(self.registration.showNotification(d.title || "Daniel's Storm Page", {
    body: d.body || 'Open the page for the latest reading.', icon: 'icon-192.png', badge: 'icon-192.png',
    tag: 'storm-alert', renotify: true, data: { url: d.url || './' },
  }));
});
self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  const url = new URL((e.notification.data && e.notification.data.url) || './', self.location.href).href;
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
    const open = list.find((c) => c.url.startsWith(self.registration.scope));
    return open ? open.focus() : self.clients.openWindow(url);
  }));
});
